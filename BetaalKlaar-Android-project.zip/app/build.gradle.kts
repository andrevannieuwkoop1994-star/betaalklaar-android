plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }

android {
    namespace = "nl.betaalklaar.app"
    compileSdk = 35
    defaultConfig {
        applicationId = "nl.betaalklaar.app"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "0.1.0"
    }
    buildTypes { release { isMinifyEnabled = false; proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro") } }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
}
